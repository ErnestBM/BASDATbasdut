from django.apps import AppConfig


class CrumengelolatimConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CRUMengelolaTim'
